# ***********************************************************************************
# [TFE22-229] Forecasting an infectious disease: COVID-19
# *******

# The fundament of this code has been written by PA Absil and Ousmane Diao. It is the
# companion Python code of https://arxiv.org/abs/2007.10492.
# However, since January 2022 and until August 2022, this code has been 
# completed/modified/adjusted by Sylvie Van Schendel for the purpose of her master 
# thesis at UCLouvain (EPL): "[TFE22-229] Forecasting an infectious disease: COVID-19".

# ***********************************************************************************

""" USER INSTRUCTIONS

Execute this file with python 3.

Tested with:
$ conda list anaconda$
# Name                    Version                  Build  Channel
anaconda                  2019.10                  py37_0  

Required package if sw_opt_solver is not set to the default:
$ conda activate
$ pip install Py-BOBYQA
PATODO: update this if needed

This file is the companion Python code of https://arxiv.org/abs/2007.10492.

The main parameters that affect the code behavior are mentioned in section "Switches" below. The parameters that the users are most likely to want to modify are marked with "!!".
"""

# ***********************************************************************************
# Changelog
# *******

# Code written by PA Absil and Ousmane Diao. There is NO WARRANTY of prediction accuracy.

# SHR_01PA.m - Started by PA on Sun 05 Jul 2020
# SHR_02PA.m - Started by PA on Sun 05 Jul 2020
#    Yields a remarkably good fit.
# SHR_03PA.m - Started by PA on Sun 05 Jul 2020
#    Version sent to Ousmane. Forked to Python version by Ousmane
# SHR_03PA_04OD.py
#    Version obtained from Ousmane on 2020-07-15
# SHR_03PA_05PA.py - Started by PA on Thu 16 Jul 2020
#    I plan to stay with Python from now on (instead of Matlab).
#    This version works well, both on the Linux command line and in Spyder. Figure 4 is particularly remarkable.
# SHR_03PA_06PA.py - Started by PA on Thu 16 Jul 2020
#    Clean up the code. Make it more compact. Use arrays of floats whenever possible. Define functions to avoid code repetition. From about 460 lines in SHR_03PA_04OD.py, we are down to about 360 lines (and the number of empty lines and comment lines has increased).
# SHR_03PA_07PA.py - Started by PA on Thu 16 Jul 2020
#     Reorder arguments of phi* functions more intuitively. Encapsulate various estimation tasks in functions estimate_* (as a preparation for loops on train periods). 
# SHR_03PA_08PA.py - Started by PA on Fri 17 Jul 2020
#     Loops on train periods.
# SHR_03PA_09PA.py - Started by PA on Fri 17 Jul 2020
#     Improve plots. Enable test_t_end.
# SHR_03PA_10PA.py - Started by PA on Sun 19 Jul 2020
#     Handle French data.
#     Plot E, L, EH. Set the bottom value of some plots to 0.
# SHR_15PA.py - Started by PA on Sun 19 Jul 2020
#     The Python version is now comparable to the Matlab version, hence this jump in the numbering.
# SHR_16PA.py - Started by PA on Mon 20 Jul 2020
#     Continue experimenting.
# SHR_17PA.py - Started by PA on Thu 06 Aug 2020
#     More experiments. Introduce show_figures. Introduce loop on cnt_state for BEL (state = province) and FRA (state = department). period_cnt -> cnt_period for notation consistency. Introduce nb_periods. Create stats_all to hold statistics. Fix the _test statistics to take test_t_end into account.
# SHR_18PA.py - Started by PA on Sat 08 Aug 2020
#     Remove MAPE() function as it was short and not much used. Print sorted statistics at the end. Print latex tables. Get rid of statss. Compute x_guess automatically. Add sMAPE and other statistics. Replace "state" by "district" in order to avoid confusion with the state of the dynamical system. Show initial guess and returned value on contour plot of obj fn. Remove old "In[<something>]:" lines. Reorganize sw_periods.
# SHR_19PA.py - Started by PA on Tue 18 Aug 2020
#     Incorporate (with a variation for E[simu_t_start] and L[simu_t_start]) modifications by Ousmane that modify the objective function to also take E[train_t_sart] and L[train_t_start] into account, in accordance with equation (11) in https://arxiv.org/abs/2007.10492v1.
# SHR_20PA.py - Started by PA on Tue 27 Oct 2020
#     Make predictions for the second wave in Belgium.
# SHR_21PA.py - Started by PA on Sat 15 May 2021
#     Prepare revision of LiB submission.
#     Create make_plots_after_periods(). Plot comparison of MASE_test-vs-time for various methods. Create safeguard in phi_basic to avoid negative values. Handle UK data. Try Savitzky-Golay filter (sw_savgol = 1). Try other optimization method (sw_opt_solver).
# SHR_22PA.py - Started by PA on Mon 24 May 2021
#     Continue preparation of revision of LiB submission.
#     Implement Runge-Kutta alternative.

# ***********************************************************************************
# Imports
# *******

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 14})
# plt.rc('xtick', labelsize='x-small')
# plt.rc('ytick', labelsize='x-small')
# plt.rcParams['style'] = "sci"  # PATODO: try to set this globally
# plt.rcParams['scilimits'] = (0,0)

# from scipy.integrate import odeint
import math 
# from mpl_toolkits.mplot3d import Axes3D
# from math import hypot
from scipy import optimize
from scipy import integrate
# from statsmodels.tsa.api import ExponentialSmoothing, SimpleExpSmoothing, Holt
# To change repertory
import os
# os.chdir ('C:\\Users\\odiao\\Desktop\\Model Covid19')
# os.getcwd ()
import copy
from datetime import datetime  # Useful for date ranges in plots.
import pybobyqa  # For optimization, as an alternative to scipy.optimize. Source: https://github.com/numericalalgorithmsgroup/pybobyqa

startTime = datetime.now()

# ***********************************************************************************
# Switches and other user choices - see also sw_periods and c_H, c_E, c_L below
# *******

sw_dataset = 'FRA'  # !! Default: 'BEL'. Currently 'BEL' and 'FRA' are available.
sw_districts = 'sum'  # !! Default: 'sum'. If 'sum', sums over all districts (i.e., provinces, departments...). If 'each', loop over all districts. sw_districts can also be the name of a district (for example, sw_districts = 'Brussels', or sw_districts = '75' for Paris, or sw_districts = 'London'). 
sw_savgol = 0  # !! Default: 0. If 1, use Savitzky-Golay filter for H_init.
sw_opt_solver = 'scipy.optimize.fmin'  # !! Default: 'scipy.optimize.fmin'. Other: 'pybobyqa'.
sw_integrator = 'Euler' # !! Default: 'Euler'. Available: 'Euler' and 'RK4'. This variable will be modified when we reach the section on the exponential model.
    
show_totinout = 1  # Default: 1 # If 1, shows plots of total, in and out and check their discrepancy.
save_figures = 0  # !! If 1, some figures will be saved in pdf format.

show_figures = 1  # If 0, no figure shown. Will be set to 0 later on if nb_districts too large.
show_hist = 0
show_H = 1  # If 1, draw a plot of the evolution of H(t).
show_S_bar = 1
show_beta_bar = 1
show_gamma = 1

# ***********************************************************************************
# Load data Belgium
# *******

if sw_dataset == 'BEL':   
    # The data comes from https://epistat.sciensano.be/Data/COVID19BE_HOSP.csv.
    # This link was provided on 22 June 2020 by Alexey Medvedev on the "Re R0 estimation" channel of the O365G-covidata team on MS-Teams.
    # The link can be reached from https://epistat.wiv-isp.be/covid/
    # Some explanations can be found at https://epistat.sciensano.be/COVID19BE_codebook.pdf

    data_raw = pd.read_csv('Data_2/Belgium/COVID19BE_HOSP_2022-05-25.csv')  # !!
    #fields = ['DATE', 'NR_REPORTING', 'TOTAL_IN','TOTAL_IN_ICU','TOTAL_IN_RESP','TOTAL_IN_ECMO','NEW_IN','NEW_OUT']

    if sw_districts == 'each':
        data_groupbydistrict = pd.DataFrame(data_raw.groupby("PROVINCE"))

# ***********************************************************************************
# Load data France
# *******

if sw_dataset == 'FRA':
    
    # The data comes from https://www.data.gouv.fr/en/datasets/donnees-hospitalieres-relatives-a-lepidemie-de-covid-19/, see donnees-hospitalieres-covid19-2020-07-10-19h00.csv

    data_raw = pd.read_csv('Data_2/France/covid-hospit-2022-05-27-19h01_standardized.csv', sep=';')  
    # some columns were added with respect to the files produced at the start of the pandemic; the "standardized" version does not have those columns. Moreover, department 46 was removed due to abnormal values in the "rad" column.
    data_raw = data_raw[data_raw.iloc[:,1]==0].reset_index(drop=True)  # Discard sex "1" and "2" (i.e., only keep sex "0" which is the sum of females and males) and reset the index in order to have a contiguous index in the DataFrame.
    
    if sw_districts == 'each':
        data_groupbydistrict = pd.DataFrame(data_raw.groupby("dep"))
    
    
# {{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
# Start loop on districts
# *******
        
if sw_districts == 'sum':
    nb_districts = 1
elif sw_districts == 'each':
    nb_districts = len(data_groupbydistrict)
else:  # else nb_districts is the name of a district
    nb_districts = 1
    
if nb_districts > 2:
    show_figures = 0  # Force figures off if there are too many districts

for cnt_district in range(nb_districts):

    if sw_districts == 'sum':
        district_name = 'sum'
        district_names = np.array(['sum'])   # without np.array, we get an error in district_names[medians_argsort]
    elif sw_districts == 'each':
        district_name = data_groupbydistrict[0][cnt_district]
        district_names = data_groupbydistrict[0]
    else:
        district_name = sw_districts
        district_names = np.array([sw_districts])

    # ***********************************************************************************
    # Process data Belgium
    # *******

    if sw_dataset == 'BEL':

        if sw_districts == 'sum':
            data_raw_district = data_raw.groupby('DATE', as_index=False).sum()  # sum over provinces
        elif sw_districts == 'each':
            data_raw_district = data_groupbydistrict[1][cnt_district]  # extract province cnt_district
        else:   
            data_raw_district = data_raw[data_raw.iloc[:,1]==sw_districts].reset_index(drop=True)   # extract district with name sw_districts

        data = data_raw_district[['DATE', 'NR_REPORTING', 'TOTAL_IN','TOTAL_IN_ICU','TOTAL_IN_RESP','TOTAL_IN_ECMO','NEW_IN','NEW_OUT']]  # exclude some useless columns
            
        # Extract relevant data and recompute new_out:
        # Source: Some variable names taken from https://rpubs.com/JMBodart/Covid19-hosp-be
        data_length = np.size(data,0)
        data_num = data.iloc[:,1:].to_numpy(dtype=float)  # extract all rows and 2nd--last columns (recall that Python uses 0-based indexing) and turn it into a numpy array of floats. The "float" type is crucial due to the use of np.nan below. (Setting an integer to np.nan does not do what it is should do.)

        #dates = data['DATE'])
        dates_raw = copy.deepcopy(data['DATE'])
        dates_raw = dates_raw.reset_index(drop=True)  # otherwise the index is not contiguous when sw_districts = 'each'
        dates = [None] * data_length
        for i in range(0,data_length):
            dates[i] = datetime.strptime(dates_raw[i],'%Y-%m-%d')

        col_total_in = 1
        col_new_in = 5
        col_new_out = 6
        total_in = data_num[:,col_total_in]
        new_in = data_num[:,col_new_in]
        new_out_raw = data_num[:,col_new_out] # there will be a non-raw due to the "Problem" mentioned below.
        new_delta = new_in - new_out_raw
        cum_new_delta = np.cumsum(new_delta)
        total_in_chg = np.hstack(([0],np.diff(total_in))) #difference between x[i+1]-x[i]
        # Problem: new_delta and total_in_chg are different, though they are sometimes close. 
        # Cum_new_delta does not go back to something close to zero, whereas it should. Hence I should not trust it.
        # I'm going to trust total_in and new_in. I deduce new_out_fixed by:
        new_out = new_in - total_in_chg   # fixed new_out
        data_totinout = np.c_[total_in,new_in,new_out]  # store total_in, new_in, and new_iout in an arraw with 3 columns


        # Show Belgian data in figures:

        if show_figures & show_totinout:
            plt.figure(figsize=(10,8))
            plt.subplot(2,2,1)
            plt.plot(dates, total_in)
            plt.plot(dates,cum_new_delta)
            plt.xlabel("Dates")
            plt.ylabel("Values")
            plt.legend(("total_in","cum_new_delta"))
            #plt.ylim([0,1000])

            plt.subplot(2,2,2)
            plt.plot(dates,new_delta)
            plt.plot(dates,total_in_chg)
            plt.xlabel("Dates")
            plt.ylabel("Values")
            plt.legend(("new_delta","total_in_chg"))

            plt.subplot(2,2,3)
            plt.plot(dates,new_out_raw)
            plt.plot(dates,new_out)
            plt.legend(("new_out_raw","new_out"))

            plt.show(block=False)  # block=False does not block the execution of the script
            
            plt.figure(figsize=(10,8))
            plt.plot(dates, total_in)
            plt.xlabel("Dates")
            plt.ylabel("Values")
            plt.title("Data - Belgium: Number of hospitalizations due to COVID-19")
            plt.show(block=False)
            
        # end if show_totinout

    # ***********************************************************************************
    # Process data France
    # *******

    elif sw_dataset == 'FRA':  # if sw_datset is 'FRA'

        if sw_districts == 'sum':
            data_raw_district = data_raw.groupby('jour', as_index=False).sum()  # sum over identical dates
        elif sw_districts == 'each':
            data_raw_district = data_groupbydistrict[1][cnt_district]  # extract department cnt_district
        else:
            data_raw_district = data_raw[data_raw.iloc[:,0]==sw_districts].reset_index(drop=True)   # extract district with name sw_districts
            
        data = data_raw_district[['jour','hosp','rea','rad','dc']]  # exclude some useless columns

        # Extract relevant data and recompute new_in:
        data_length = np.size(data,0)
        data_num = data.iloc[:,1:].to_numpy(dtype=float)

        #dates = data['DATE'])
        dates_raw = copy.deepcopy(data['jour'])
        dates_raw = dates_raw.reset_index(drop=True)  # otherwise the index is not contiguous when sw_districts = 'each'
        dates = [None] * data_length
        for i in range(0,data_length):
            dates[i] = datetime.strptime(dates_raw[i],'%Y-%m-%d')

        col_total_in = 0
        col_new_in = np.nan   # no column for new_in in French data
        col_new_out = np.nan  # to get new_out we have to sum 'rad' and 'dc'
        total_in = data_num[:,col_total_in]
        new_out = np.hstack(([0],np.diff(data_num[:,2] + data_num[:,3])))
        total_in_chg = np.hstack(([0],np.diff(total_in)))
        new_in = new_out + total_in_chg
        data_totinout = np.c_[total_in,new_in,new_out]  # store total_in, new_in, and new_iout in an arraw with 3 columns

        # Show French data in figures:

        if show_figures & show_totinout:
            plt.figure(figsize=(10,8))
            plt.plot(dates, total_in)
            plt.xlabel("Dates")
            plt.ylabel("Values")
            plt.title("Data - France: Number of hospitalizations due to COVID-19")
            plt.show(block=False)
            
    # end if sw_dataset

    # ***********************************************************************************
    # Select train and test periods
    # *******

    sw_periods = '1.2.61'
    # '1.2.60': train period around the first peak, selected automatically without data leakage
    # '1.2.61': train period around the second-to-last peak

    if sw_periods == '1.2.60':  # put train period around peak while avoiding data leakage
        # *keep*
        N = 7  # The window length of moving average will be 2N+1.
        total_in_MA = total_in * np.nan  # MA: moving average
        # Find the first time where the latest peak of total_in_MA is N days behind:
        t = -1; t_max = -1
        while t_max != t-N or total_in_MA[t_max] == 0 or t-2*N < 0:
            t = t + 1
            total_in_MA[t] = np.sum(total_in[max(0,t-N):min(t+N+1,len(total_in))]) / (min(t+N+1,len(total_in)) - max(0,t-N))
            t_max = np.argmax(total_in_MA[:t+1])
        train_t_start_vals = np.array([t-2*N])
        train_t_end_vals = np.array([t+N+1])  # The train period stops the day before train_t_end_vals. Observe that the data from train_t_end_vals onward has not been used.
        test_t_end_vals = train_t_end_vals + 60
        
    if sw_periods == '1.2.61': # Train period = Avant-dernier pic
        if sw_dataset == 'BEL': train_t_start_vals = np.array([683])
        if sw_dataset == 'FRA': train_t_start_vals = np.array([680])
        train_t_end_vals   = train_t_start_vals + 21
        test_t_end_vals    = train_t_end_vals + 60
        
    # ***********************************************************************************
    # Preparation
    # *******

    nb_periods = len(train_t_start_vals)  # number of periods, i.e., number of test-train experiments on the same data
    
    # Make sure that times are integers:
    train_t_start_vals = train_t_start_vals.astype(int)
    train_t_end_vals = train_t_end_vals.astype(int)
    test_t_end_vals = test_t_end_vals.astype(int)

    # Restrict test_t_end_vals from above by len(total_in):
    test_t_end_vals = np.minimum(test_t_end_vals,len(total_in))

    # Weights of the terms of the cost function:
    c_H, c_E, c_L = 1, 1, 1 # !! Default: c_H = 1; c_E = 1; c_L = 1 (it gives a good MAPE_test)
    c_HEL = [c_H,c_E,c_L]

    # Part of file name of figures:
    name_root = os.path.splitext(os.path.basename(__file__))[0] + '_py_' + sw_dataset + sw_districts + '_1sttraintstart' + str(train_t_start_vals[0]) + '_1sttraintend' + str(train_t_end_vals[0]) + '_1sttesttend' + str(test_t_end_vals[0]) + '_c' + str(c_H) + str(c_E) + str(c_L)
    fig_name_root = 'Figures/' + name_root

    # Time axis of plots:
    time_axis = dates    # can be dates or np.arange(length(total_in))
    #time_axis = np.arange(len(total_in))    # can be dates (default) or np.arange(length(total_in))    
    

    # ***********************************************************************************
    # Show available data
    # *******

    if show_figures:
        plt.figure(figsize=(10,8))
        #plt.subplot(2,2,1)
        plt.plot(time_axis, total_in/np.max(total_in), "-", color='gray', label="Total_in norm\'d")
        plt.plot(time_axis, new_out/np.max(np.hstack((new_in,new_out))), 'm--', label="new_in norm\'d")
        plt.plot(time_axis, new_in/np.max(np.hstack((new_in,new_out))), 'b-.', label="new_out norm\'d")
        plt.plot(time_axis, new_in * total_in / np.max(new_in * total_in), ':', color='tab:purple', label="total_in * new_in norm\'d")
        plt.xlabel("Dates")
        plt.ylabel("Values")
        plt.legend()

        plt.show(block=False)


    #***********************************************************************************
    # Define H_init estimation function
    # *******

    def estimate_H_init(tspan_train,data_totinout_train):
        
        # Estimate H_init:
        if sw_savgol == 0:
            H_init = data_totinout_train[tspan_train[0],0]
        else:  #
            #total_in[max(0,t-N):min(t+N+1,len(total_in))]
            savgol_N_half = 3
            savgol_start = max(0,train_t_start-savgol_N_half)
            savgol_end = min(train_t_start+savgol_N_half,train_t_end)
            savgol_p = np.polyfit(np.arange(savgol_start,savgol_end),data_totinout_train[savgol_start:savgol_end,0],2)
            H_init = np.polyval(savgol_p,train_t_start)
        return H_init

    #***********************************************************************************
    # Define gamma estimation function
    # *******
    # Model for gamma: new_out = gamma * total_in

    def estimate_gamma(tspan_train,data_totinout_train):

        train_t_start = tspan_train[0]
        train_t_end = tspan_train[1]
        total_in_train = data_totinout_train[:,0]
        new_out_train = data_totinout_train[:,2]

        # Estimator by ratio of means:
        #gamma_hat_RM = np.sum(new_out_train[0:train_t_end])/np.sum(total_in_train[0:train_t_end]) # This version uses all the non-test data.
        gamma_hat_RM = np.sum(new_out_train[train_t_start:train_t_end])/np.sum(total_in_train[train_t_start:train_t_end])  # This version uses only the "train" period. Since few patients are discharged over the weekend, it is recommended to have train_t_end_vals = train_t_start_vals + 14.

        # Estimator by mean of ratios:
        #gamma_hat_MR = np.mean(new_out_train[train_t_start:train_t_end]/total_in_train[train_t_start:train_t_end])

        # Estimator by least squares:
        #gamma_hat_LS = total_in_train[0:train_t_end]\new_out_train[0:train_t_end]
        #gamma_hat_LS = np.linalg.lstsq(np.c_[total_in_train[0:train_t_end]],new_out_train[0:train_t_end], rcond=None)[0]

        # Estimator by ratio of means on all data (test and train):  not legitimate
        #gamma_hat_all_RM = sum(new_out_train)/sum(total_in_train);

        # I observe that the RM and LS estimates are quite close. Let's keep:
        gamma = gamma_hat_RM  # !!
        #gamma = gamma_hat_all_RM;  % not legitimate

        return gamma
    # end def estimate_gamma

    length_train_period = train_t_end_vals[0] - train_t_start_vals[0]
    length_test_period  = test_t_end_vals[0] - train_t_end_vals[0] + 1

    H_curves = np.zeros((length_test_period,length_train_period))
    beta_bar_tab = np.full(length_train_period, np.nan)  # set storage
    
    if sw_dataset == 'BEL':
        # Estimated parameters
        gamma = 0.0825486312771102
        beta_bar_0 = 2.8811455049417232e-11
        beta_bar_1 = 1.514439838120268e-08
        # Initial states
        H_init = 3695.0
        S_bar_init = 10879.802316458023
        
    if sw_dataset == 'FRA':
        # Estimated parameters
        gamma = 0.07349874401630409
        beta_bar_0 = 2.948907540920087e-16
        beta_bar_1 = 9.247401733540447e-10
        # Initial states
        H_init = 30982.0
        S_bar_init = 138184.22469009392
    
    
    for t_loop in np.arange(train_t_start_vals[0], train_t_end_vals[0]):
        
        beta_bar_tab[t_loop-train_t_start_vals[0]] = beta_bar_0 + beta_bar_1 * t_loop
        
        beta_bar = beta_bar_tab[t_loop-train_t_start_vals[0]]

        # ***********************************************************************************
        # Define several functions: the SH simulation function (simu()); the general cost function on which the various parameter estimations will be based (phi_basic()); a function that returns statistics (make_stats()); a function that draw plots of simulation results (make_plots()); a function that draws a plot of the error as a function of the end of the train period (make_plots_after_periods())
        # *******
    
        # Define the simulation function of the SH model:
        def simu(beta_bar,gamma,S_bar_init,H_init,tspan):

            simu_t_start = tspan[0]
            simu_t_end = tspan[1]  # The time before which we stop, i.e., the last returned values are at t = simu_t_end - 1.
            S_bar = np.full(simu_t_end, np.nan)  # set storage
            H = np.full(simu_t_end, np.nan)  # set storage
            E = np.full(simu_t_end, np.nan)  # set storage
            L = np.full(simu_t_end, np.nan)  # set storage
            
            
            if model == 'SH':  # SH model
                if sw_integrator == 'Euler':  # Euler integrator
                    
                    S_bar[simu_t_start] = S_bar_init
                    H[simu_t_start] = H_init
                    E[simu_t_start] = beta_bar * S_bar[simu_t_start] * H[simu_t_start]
                    L[simu_t_start] = gamma * H[simu_t_start]
                    
                    for t in np.arange(simu_t_start,simu_t_end-1):
                        S_bar[t+1] = S_bar[t] - beta_bar * S_bar[t] * H[t]
                        H[t+1] = H[t] + beta_bar * S_bar[t] * H[t] - gamma * H[t]
                        E[t+1] = beta_bar * S_bar[t+1] * H[t+1]
                        L[t+1] = gamma * H[t+1]
            #     elif sw_integrator == 'RK4':  # Runge-Kutta integrator
            #         def fun_SH_RHS(t,y):
            #             dot_y = np.zeros(2)
            #             dot_y[0] = -beta_bar * y[0] * y[1]
            #             dot_y[1] = beta_bar * y[0] * y[1] - gamma * y[1]
            #             return dot_y
            #         sol_RK4 = integrate.solve_ivp(fun=fun_SH_RHS, t_span=tspan, y0=[S_bar_init,H_init], method='RK45', t_eval=range(tspan[0],tspan[1],1), dense_output=False, events=None, vectorized=False, args=None)
            #         S_bar[simu_t_start:simu_t_end] = sol_RK4.y[0,:]
            #         H[simu_t_start:simu_t_end] = sol_RK4.y[1,:]
            #         E = beta_bar * S_bar * H
            #         L = gamma * H
            # elif model == 'exp':
            #     for t in np.arange(simu_t_start,simu_t_end):
            #         S_bar[t] = np.nan
            #         H[t] = H_init * math.exp(-gamma*(t-simu_t_start))
            #         E[t] = np.nan
            #         L[t] = np.nan
            return (S_bar,H,E,L)
        # end def simu

        # Define the loss function in terms of all the possible decision variables, i.e., beta_bar,gamma,S_bar_init,H_init :
        def phi_basic(beta_bar,gamma,S_bar_init,H_init,tspan_train,data_totinout_train,c_HEL):
            if any(np.array([beta_bar,gamma,S_bar_init,H_init])<0):
                return np.inf  # Negative values of the state variables and parameters are not allowed: we assign them an infinite cost
            else:
                # Extract variables from input:
                c_H, c_E, c_L = c_HEL  #coefficients of the terms of the cost function. Default: c_H = 1; c_E = 1; c_L = 1 (it gives a good MAPE_test)
                train_t_start, train_t_end = tspan_train
                _, H, E, L = simu(beta_bar,gamma,S_bar_init,H_init,tspan=tspan_train)  # "_" because S_bar is not involved in the cost
                # Compute the cost (discrepancy between observed and simulated):
                cost = c_H * (np.linalg.norm(H[train_t_start:train_t_end]-data_totinout_train[train_t_start:train_t_end,0]))**2 + c_E * (np.linalg.norm(E[train_t_start:train_t_end]-data_totinout_train[train_t_start:train_t_end,1]))**2 + c_L * (np.linalg.norm(L[train_t_start+1:train_t_end]-data_totinout_train[train_t_start+1:train_t_end,2]))**2
                return cost
    
        # Define function that gathers statistics in dict stats_all:
        def make_stats(stats_all,beta_bar,gamma,S_bar_init,H_init,tspan_train,dates,data_totinout):
            stats_keys = ['RMSE_train', 'RMSE_test', 'RMSE_test/RMSE_train', 'RRSE_train', 'RRSE_test', 'RRSE_test/RRSE_train', 'MAE_train', 'MAE_test', 'MAE_test/MAE_train', 'MASE', 'MASE_train', 'MASE_test', 'MASE_test/MASE_train', 'RelMAE_train', 'RelMAE_test', 'RelMAE_test/RelMAE_train', 'nMAE_train', 'nMAE_test', 'nMAE_test/nMAE_train', 'rnMAE_train', 'rnMAE_test', 'rnMAE_test/rnMAE_train', 'MAPE_train', 'MAPE_test', 'MAPE_test/MAPE_train', 'sMAPE_train', 'sMAPE_test', 'sMAPE_test/sMAPE_train']
    
            if not stats_all:  # If stats_all is still the empty dictionary, let's populate it.
                for key in stats_keys:
                    stats_all[key] = np.full((nb_districts,nb_periods),np.nan)
    
            S_bar, H, E, L = simu(beta_bar, gamma, S_bar_init, H_init, tspan=[tspan_train[0],len(total_in)])
                
            RMSE_train = np.linalg.norm(H[train_t_start:train_t_end] - total_in[train_t_start:train_t_end]) / math.sqrt(train_t_end-train_t_start)
            RMSE_test = np.linalg.norm(H[train_t_end:test_t_end] - total_in[train_t_end:test_t_end]) / math.sqrt(test_t_end-train_t_end)
            stats_all['RMSE_train'][cnt_district,cnt_period] = RMSE_train
            stats_all['RMSE_test'][cnt_district,cnt_period] = RMSE_test
            stats_all['RMSE_test/RMSE_train'][cnt_district,cnt_period] = stats_all['RMSE_test'][cnt_district,cnt_period] / stats_all['RMSE_train'][cnt_district,cnt_period]
            stats_all['RRSE_train'][cnt_district,cnt_period] = np.sqrt( np.sum((total_in[train_t_start:train_t_end] - H[train_t_start:train_t_end])**2) / np.sum((total_in[train_t_start:train_t_end] - np.mean(total_in[train_t_start:train_t_end]))**2) )
            stats_all['RRSE_test'][cnt_district,cnt_period] = np.sqrt( np.sum((total_in[train_t_end:test_t_end] - H[train_t_end:test_t_end])**2) / np.sum((total_in[train_t_end:test_t_end] - np.mean(total_in[train_t_end:test_t_end]))**2) )  # Root Relative Squared Error
            stats_all['RRSE_test/RRSE_train'][cnt_district,cnt_period] = stats_all['RRSE_test'][cnt_district,cnt_period] / stats_all['RRSE_train'][cnt_district,cnt_period]
            MAE_train = np.mean(np.abs(total_in[train_t_start:train_t_end]-H[train_t_start:train_t_end]))
            MAE_test = np.mean(np.abs(total_in[train_t_end:test_t_end]-H[train_t_end:test_t_end]))
            stats_all['MAE_train'][cnt_district,cnt_period] = MAE_train
            stats_all['MAE_test'][cnt_district,cnt_period] = MAE_test
            stats_all['MAE_test/MAE_train'][cnt_district,cnt_period] = stats_all['MAE_test'][cnt_district,cnt_period] / stats_all['MAE_train'][cnt_district,cnt_period]
            stats_all['MASE'][cnt_district,cnt_period] = np.mean(np.abs(total_in[train_t_end:test_t_end]-H[train_t_end:test_t_end])) / np.mean(np.abs(total_in[train_t_start+1:train_t_end]-total_in[train_t_start:train_t_end-1]))  # Mean Absolute Scaled Error (dubious because we make multi-step forecasts, not one-step-ahead forecasts)
            stats_all['MASE_train'][cnt_district,cnt_period] = MAE_train / np.mean(np.abs(total_in[train_t_start+1:train_t_end]-total_in[train_t_start:train_t_end-1]))
            stats_all['MASE_test'][cnt_district,cnt_period] = MAE_test / np.mean(np.abs(total_in[train_t_end+1:test_t_end]-total_in[train_t_end:test_t_end-1]))  # MAE divided by MAE of the prescient naive one-step-ahead predictor (that predicts total_in[t] by total_in[t-1]). Since the decrease is slow, this can be interpreted as the MAE divided by the noise level. If it gets below 1, then the fit is visually excellent. This measure is strongly inspired from Hyndman & Koehler 2006 (https://doi.org/10.1016/j.ijforecast.2006.03.001).
            stats_all['MASE_test/MASE_train'][cnt_district,cnt_period] = stats_all['MASE_test'][cnt_district,cnt_period] / stats_all['MASE_train'][cnt_district,cnt_period]
            stats_all['RelMAE_train'][cnt_district,cnt_period] = MAE_train / np.mean(np.abs(total_in[train_t_start:train_t_end]-total_in[train_t_start-1]))
            stats_all['RelMAE_test'][cnt_district,cnt_period] = MAE_test / np.mean(np.abs(total_in[train_t_end:test_t_end]-total_in[train_t_end-1]))  # relative MAE, i.e., MAE of H divided by MAE of constant forecast total_in[train_t_end-1]
            stats_all['RelMAE_test/RelMAE_train'][cnt_district,cnt_period] = stats_all['RelMAE_test'][cnt_district,cnt_period] / stats_all['RelMAE_train'][cnt_district,cnt_period]
            stats_all['nMAE_train'][cnt_district,cnt_period] = MAE_train / np.mean(np.abs(total_in[train_t_start:train_t_end]))
            stats_all['nMAE_test'][cnt_district,cnt_period] = MAE_test / np.mean(np.abs(total_in[train_t_end:test_t_end]))  # normalized MAE, i.e., MAE of H divided by MAE of constant forecast 0
            stats_all['nMAE_test/nMAE_train'][cnt_district,cnt_period] = stats_all['nMAE_test'][cnt_district,cnt_period] / stats_all['nMAE_train'][cnt_district,cnt_period]
            stats_all['rnMAE_train'][cnt_district,cnt_period] = MAE_train / np.ptp(total_in[train_t_start:train_t_end])
            if train_t_end < test_t_end:  # if test is not empty (otherwise np.ptp below gives an error)
                stats_all['rnMAE_test'][cnt_district,cnt_period] = MAE_test / np.ptp(total_in[train_t_end:test_t_end])  # range-normalized MAE, i.e., MAE of H divided by the (diameter of the) range of the true values. (ptp means "peak to peak")
                stats_all['rnMAE_test/rnMAE_train'][cnt_district,cnt_period] = stats_all['rnMAE_test'][cnt_district,cnt_period] / stats_all['rnMAE_train'][cnt_district,cnt_period]
            else:
                stats_all['rnMAE_test'][cnt_district,cnt_period] = np.nan
                stats_all['rnMAE_test/rnMAE_train'][cnt_district,cnt_period] = np.nan
            stats_all['MAPE_train'][cnt_district,cnt_period] = np.mean(np.abs( (total_in[train_t_start:train_t_end]-H[train_t_start:train_t_end]) / total_in[train_t_start:train_t_end] ))
            stats_all['MAPE_test'][cnt_district,cnt_period] = np.mean(np.abs( (total_in[train_t_end:test_t_end]-H[train_t_end:test_t_end]) / total_in[train_t_end:test_t_end] ))
            stats_all['MAPE_test/MAPE_train'][cnt_district,cnt_period] = stats_all['MAPE_test'][cnt_district,cnt_period] / stats_all['MAPE_train'][cnt_district,cnt_period]
            stats_all['sMAPE_train'][cnt_district,cnt_period] = np.mean(np.abs( (total_in[train_t_start:train_t_end]-H[train_t_start:train_t_end]) / ((total_in[train_t_start:train_t_end]+H[train_t_start:train_t_end])/2) ))
            stats_all['sMAPE_test'][cnt_district,cnt_period] = np.mean(np.abs( (total_in[train_t_end:test_t_end]-H[train_t_end:test_t_end]) / ((total_in[train_t_end:test_t_end]+H[train_t_end:test_t_end])/2) ))  # symmetric MAPE
            stats_all['sMAPE_test/sMAPE_train'][cnt_district,cnt_period] = stats_all['sMAPE_test'][cnt_district,cnt_period] / stats_all['sMAPE_train'][cnt_district,cnt_period]
            return
        # end def make_stats
    
        # Define function for plots:
        def make_plots(beta_bar,gamma,S_bar_init,H_init,tspan_train,dates,data_totinout):
            S_bar, H, E, L = simu(beta_bar, gamma, S_bar_init, H_init, tspan=[tspan_train[0],len(total_in)])
            nb_subplots = show_H + show_S_bar + show_beta_bar + show_gamma
            if nb_subplots == 4:
                nb_subplot_rows = 2
                nb_subplot_cols = 2
                plt.rc('xtick', labelsize='x-small')
                plt.rc('ytick', labelsize='x-small')
            else:
                nb_subplot_rows = 1
                nb_subplot_cols = nb_subplots 
            cnt_subplot = 0
            nb_xticks = 4
            time_axis_ticks = [None] * nb_xticks
            time_axis_ticks_ind = np.linspace(0,np.max(test_t_end_vals)-1,nb_xticks,dtype=int)
            for i in range(0,nb_xticks):
                time_axis_ticks[i] = time_axis[time_axis_ticks_ind[i]]
    
            if show_H:
                cnt_subplot = cnt_subplot + 1
                plt.subplot(nb_subplot_rows,nb_subplot_cols,cnt_subplot)
    
                if cnt_period == 0:   # assign plot labels
                    plt.plot(time_axis[0:np.max(test_t_end_vals)],total_in[0:np.max(test_t_end_vals)], "-", color='gray', label="Total_in", linewidth=1)
                    plt.plot(time_axis[train_t_start:train_t_end],H[train_t_start:train_t_end],'b--', label="H_train")
                    plt.plot(time_axis[train_t_end-1:test_t_end],H[train_t_end-1:test_t_end],'r-.', label="H_pred")
                    plt.legend()
                else:
                    plt.plot(time_axis[train_t_start:train_t_end],H[train_t_start:train_t_end],'b--')
                    plt.plot(time_axis[train_t_end-1:test_t_end],H[train_t_end-1:test_t_end],'r-.')
                plt.xticks(time_axis_ticks)
                plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
                if cnt_period == nb_periods-1:
                    plt.ylim(bottom=0)
    
            if show_S_bar:
                cnt_subplot = cnt_subplot + 1
                plt.subplot(nb_subplot_rows,nb_subplot_cols,cnt_subplot)
                if cnt_period == 0:   # assign plot labels
                    plt.plot(time_axis[0:train_t_end],S_bar[0:train_t_end],'b--', label="S_bar_train")
                    plt.plot(time_axis[train_t_end-1:test_t_end],S_bar[train_t_end-1:test_t_end],'r-.', label="S_bar_pred")
    
                    plt.legend()
                else:
                    plt.plot(time_axis[train_t_start:train_t_end],S_bar[train_t_start:train_t_end],'b--')
                    plt.plot(time_axis[train_t_end-1:test_t_end],S_bar[train_t_end-1:test_t_end],'r-.')
                plt.xticks(time_axis_ticks)
                plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
                if cnt_period == nb_periods-1:
                    plt.ylim(bottom=0)
    
            if show_beta_bar:
                cnt_subplot = cnt_subplot + 1
                plt.subplot(nb_subplot_rows,nb_subplot_cols,cnt_subplot)
                if cnt_period == 0:   # assign plot labels
                    plt.plot(time_axis[train_t_start:train_t_end],beta_bar*np.ones(train_t_end-train_t_start),'b--', label="beta_bar_train")
                    plt.plot(time_axis[train_t_end-1:test_t_end],beta_bar*np.ones(test_t_end-train_t_end+1),'r-.', label="beta_bar_pred")
                    plt.legend()
                else:
                    plt.plot(time_axis[train_t_start:train_t_end],beta_bar*np.ones(train_t_end-train_t_start),'b--')
                    plt.plot(time_axis[train_t_end-1:test_t_end],beta_bar*np.ones(test_t_end-train_t_end+1),'r-.')
                plt.xticks(time_axis_ticks)
                plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
                if cnt_period == nb_periods-1:
                    plt.ylim(bottom=0)
    
            if show_gamma:
                cnt_subplot = cnt_subplot + 1
                plt.subplot(nb_subplot_rows,nb_subplot_cols,cnt_subplot)
                if cnt_period == 0:   # assign plot labels
                    plt.plot(time_axis[train_t_start:train_t_end],gamma*np.ones(train_t_end-train_t_start),'b--', label="gamma_train")
                    plt.plot(time_axis[train_t_end-1:test_t_end],gamma*np.ones(test_t_end-train_t_end+1),'r-.', label="gamma_pred")
                    plt.legend()
                else:
                    plt.plot(time_axis[train_t_start:train_t_end],gamma*np.ones(train_t_end-train_t_start),'b--')
                    plt.plot(time_axis[train_t_end-1:test_t_end],gamma*np.ones(test_t_end-train_t_end+1),'r-.')
                plt.xticks(time_axis_ticks)
                plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
                if cnt_period == nb_periods-1:
                    plt.ylim(bottom=0)
            return
        # end def make_plots
    
    
        # ***********************************************************************************
        # Optimization wrt beta_bar and S_bar_init
        # *******
        model = 'SH'  # This affects simu()
        
        # Define the loss function where "x" contains the decision variables of interest in this section of the code, namely x := [beta_bar,S_bar_init]:
        def phi(x,gamma,H_init,tspan_train,data_totinout_train,c_HEL):
            return phi_basic(x[0],gamma,x[1],H_init,tspan_train,data_totinout_train,c_HEL)
    
        # Extract train variables in order to do a first plot of the cost function:
        train_t_start = train_t_start_vals[0]
        train_t_end = train_t_end_vals[0]
        test_t_end = test_t_end_vals[0]
        tspan_train = [train_t_start,train_t_end]
        data_totinout_train = copy.deepcopy(data_totinout)  # in order to be able to "hide" entries in data_totinout_train without changing data_totinout
        data_totinout_train[train_t_end:,:] = np.nan  # Beware that data_totinout_train has to be floats.
    
        # Estimate H_init:
        H_init = estimate_H_init(tspan_train,data_totinout_train)
    
        # Estimate gamma:
        gamma = estimate_gamma(tspan_train,data_totinout_train)  # estimate gamma
    
        # Define anonymous function for use in optimization solver:
        fun = lambda x:phi(x,gamma,H_init,tspan_train,data_totinout_train,c_HEL)  # function phi is defined above
    
        # # First plot of cost function, to get an idea of an init point for the optimization solver:
        # if show_figures:
        #     beta_bar_vals = np.linspace(0,2e-5,100)  #beta_bar_vals = np.linspace(8e-6,12e-6,10)
        #     S_bar_init_vals = np.linspace(0,2e4,100)   #S_bar_init_vals = np.linspace(8e3,10e3,10)
        #     X,Y = np.meshgrid(beta_bar_vals,S_bar_init_vals)
        #     Z = np.full((np.size(X,0),np.size(X,1)), np.nan)
        #     for i in np.arange(0,np.size(X,0)):
        #          for j in np.arange(0,np.size(X,1)):
        #                 #print(i,j)
        #                 #[X[i,j],Y[i,j]]
        #                 Z[i,j] = fun([X[i,j],Y[i,j]]) 
        #     plt.figure(figsize=(10,8))
        #     plt.contourf(X, Y, Z)
        #     plt.colorbar()
        #     plt.ticklabel_format(style="sci", scilimits=(0,0))
        #     plt.show(block=False)
    
        # Define function for the estimation of beta_bar and S_bar_init:
        def estimate_betabar_Sbarinit(tspan_train,data_totinout_train,c_HEL):  # estimation method with beta_bar and S_bar_init as optimization variables
            H_init = estimate_H_init(tspan_train,data_totinout_train)
            gamma = estimate_gamma(tspan_train,data_totinout_train)
            fun = lambda x:phi(x,gamma,H_init,tspan_train,data_totinout_train,c_HEL)  # function phi is defined above
            
            # beta_bar_guess, S_bar_init_guess = estimate_successive_betabar_Sbarinit(tspan_train,data_totinout_train)
            beta_bar_guess = beta_bar
            total_in_train = data_totinout_train[:,0]
            new_in_train = data_totinout_train[:,1]
            S_bar_init_guess = new_in_train[train_t_start] / (beta_bar_guess * total_in_train[train_t_start])
            
            x_guess = [beta_bar_guess, S_bar_init_guess]
            #x_guess = [1e-5,1e4]  # hard-coded guess. Sugg: [1e-5,1e4]
            if sw_opt_solver == 'pybobyqa':
                soln = pybobyqa.solve(fun,x_guess,bounds=(np.zeros(np.shape(x_guess)),np.inf*np.ones(np.shape(x_guess))),seek_global_minimum=True) # PATODO
                x_opt = soln.x
            else:
                x_opt = optimize.fmin(fun,x_guess)  # call the optimization solver
                #x_opt = optimize.fmin(fun,x_guess,maxiter=1e4,maxfun=1e4)
            beta_bar_opt = x_opt[0]
            S_bar_init_opt = x_opt[1]
            fun_opt = fun([beta_bar_opt,S_bar_init_opt])  # value of the minimum, useful for plot
            
            return (beta_bar_opt, S_bar_init_opt, gamma, H_init, fun_opt, fun, x_guess)
    
    
        if show_figures:
            plt.figure(figsize=(10,8))
    
        # Storage for statistics as a dictionary of numpy arrays:
        # If we are dealing with the first district, then we have to create stats_all 
        if cnt_district == 0:   
            stats_all = {}   # Create dict stats_all. Using make_stats(s), it will become a dictionary of numpy arrays where we will record statistics for the various districts and periods.
    
        # [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
        # Start loop on train periods:
        for cnt_period in range(0, nb_periods):
    
            # Extract train variables for period cnt_period:
            train_t_start = train_t_start_vals[cnt_period]
            train_t_end = train_t_end_vals[cnt_period]
            test_t_end = test_t_end_vals[cnt_period]
            tspan_train = [train_t_start,train_t_end]
            # The test data is defined to be all the data that occurs from train_t_end.
            # Replace test data by NaN in *_train variables.
            data_totinout_train = copy.deepcopy(data_totinout)  # in order to be able to "hide" entries in data_totinout_train without changing data_totinout
            data_totinout_train[train_t_end:,:] = np.nan  # Beware that data_totinout_train has to be floats.
            # ! Make sure to use only these *_train variables in the train phase.
    
            # # Estimate beta_bar and S_bar_init by optimizing the cost function:
            # beta_bar_opt, S_bar_init_opt, gamma, H_init, fun_opt, fun, x_guess = estimate_betabar_Sbarinit(tspan_train,data_totinout_train,c_HEL)
    
            # # Compute statistics:
            # make_stats(stats_all,beta_bar_opt, gamma, S_bar_init_opt, H_init, tspan_train, dates, data_totinout)
    
            # Plot true and simulated H, and simulated S_bar:
            if show_figures:
                # make_plots(beta_bar_opt,gamma,S_bar_init_opt,H_init,tspan_train,dates,data_totinout)  
                
                train_t_start = train_t_start_vals[cnt_period]
                train_t_end = train_t_end_vals[cnt_period]
                test_t_end = test_t_end_vals[cnt_period]
                tspan_train = [train_t_start,train_t_end]
                data_totinout_train = copy.deepcopy(data_totinout)  # in order to be able to "hide" entries in data_totinout_train without changing data_totinout
                data_totinout_train[train_t_end:,:] = np.nan
                
                
                beta_bar_opt, S_bar_init_opt, gamma, H_init, fun_opt, fun, x_guess = estimate_betabar_Sbarinit(tspan_train,data_totinout_train,c_HEL)
                
                beta_bar = beta_bar_opt
                S_bar_init = S_bar_init_opt
                S_bar, H, E, L = simu(beta_bar, gamma, S_bar_init, H_init, tspan=[tspan_train[0],len(total_in)])

                plt.figure(figsize=(10,8))
                plt.plot(dates[train_t_start-60:test_t_end+1], total_in[train_t_start-60:test_t_end+1], '-', color='gray', label='Initial total_in')
                plt.plot(time_axis[train_t_start:train_t_end],H[train_t_start:train_t_end],'b--', label="H_train")
                plt.plot(time_axis[train_t_end-1:test_t_end],H[train_t_end-1:test_t_end],'r-.', label="H_pred")
                plt.xlabel("Dates")
                plt.ylabel("Values")
                if sw_dataset == 'BEL': plt.title("Belgian forecasts: Number of hospitalizations due to COVID-19")
                if sw_dataset == 'FRA': plt.title("French forecasts: Number of hospitalizations due to COVID-19")
                plt.legend()
                plt.show(block=False)
                
                H_curves[:,t_loop-train_t_start_vals[0]] = H[train_t_end-1:test_t_end]
            #end if cnt_period
    
        # end loop on train periods
        # ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
    
        # if show_figures:  # Show and save the figure that was created above by the calls to make_plots().
        #     #plt.title("Optimized wrt beta_bar and S_bar_init")
        #     plt.show(block=False)
        #     if save_figures: plt.savefig(fig_name_root + '_2D.pdf', format='pdf', bbox_inches='tight')
    
        # if show_figures:
        #     # Plot the cost function around the found minimizer:
        #     #beta_bar_vals = np.linspace(0,beta_bar_opt*2,100)
        #     beta_bar_vals = np.linspace(0,max(beta_bar_opt,x_guess[0])*2,100)        
        #     #S_bar_init_vals = np.linspace(0,S_bar_init_opt*2,100)
        #     S_bar_init_vals = np.linspace(0,max(S_bar_init_opt,x_guess[1])*2,100)        
        #     X,Y = np.meshgrid(beta_bar_vals,S_bar_init_vals)
        #     Z = np.full((np.size(X,0),np.size(X,1)), np.nan)
        #     for i in np.arange(0,np.size(X,0)):
        #          for j in np.arange(0,np.size(X,1)):
        #             Z[i,j] = math.log10(fun([X[i,j],Y[i,j]])-fun_opt*0.70)   # PATODO investigate this for UK data
        #     plt.figure(figsize=(10,8))
        #     plt.contourf(X, Y, Z)
        #     plt.colorbar()
        #     plt.plot(x_guess[0],x_guess[1],'ro')  # show initial guess provided to optimization solver
        #     plt.plot(beta_bar_opt,S_bar_init_opt,'r*')  # show point returned by optimization solver
        #     #plt.title('log10(fun - fun\_opt*.90))')
        #     plt.ticklabel_format(style="sci", scilimits=(0,0))
        #     plt.show(block=False)
        #     #fig_name = 'Figures/' + os.path.basename(__file__) + sw_dataset + '_traintstart' + str(train_t_start_vals[0]) + '_traintstop' + str(train_t_end_vals[0]) + '_c' + str(c_H) + str(c_E) + str(c_L) + '_contour.pdf'
        #     if save_figures: plt.savefig(fig_name_root + '_contour.pdf', format='pdf', bbox_inches='tight')
    
        # if show_figures:  #21PA
        #     make_plots_after_periods(stats_all_to_plot=stats_all)
        #     #fig_name = 'Figures/' + os.path.basename(__file__) + sw_dataset + '_traintstart' + str(train_t_start_vals[0]) + '_traintstop' + str(train_t_end_vals[0]) + '_c' + str(c_H) + str(c_E) + str(c_L) + '_MASE.pdf'
        #     if save_figures: plt.savefig(fig_name_root + '_2D_MASE.pdf', format='pdf', bbox_inches='tight')
        #     #wait = input("press enter to continue")
    
    # End loop on districts
    # }}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

# ***********************************************************************************
# Show histograms
# *******

def make_hist(stats_key):
    plt.figure(figsize=(10,8))
    MAPE_test_hist = np.mean(stats_all[stats_key], axis=1)
    MAPE_test_hist = MAPE_test_hist[MAPE_test_hist<np.inf]  # Remove inf entries if any
    plt.hist(MAPE_test_hist, bins=10**np.linspace(np.log10(np.min(MAPE_test_hist)),np.log10(np.max(MAPE_test_hist)),10))
    plt.xscale('log')
    plt.xlabel(stats_key)
    plt.show(block=False)

if show_hist and nb_districts > 1:   # no point showing a histogram if there is only one district
    make_hist('MAPE_test')
    make_hist('RelMAE_test')
    
# ***********************************************************************************
# Print final results
# *******   

print(" ")
print("Country: ", sw_dataset)
print("Train period = Second-to-last peak.")
 
plt.figure(figsize=(10,8))
plt.plot(dates[train_t_start-60:test_t_end+1], total_in[train_t_start-60:test_t_end+1], "-", color='gray', label='Initial data')
plt.plot(time_axis[train_t_start:train_t_end],H[train_t_start:train_t_end],'b--', label="H_train")
for i in range(length_train_period):
    plt.plot(dates[train_t_end:test_t_end+1], H_curves[:,i], '-g', label=('' if i==0 else '_') + 'H_pred')
plt.xlabel("Dates")
plt.ylabel("Values")
if sw_dataset == 'BEL': plt.title("Belgium: Confidence interval - Method 3")
if sw_dataset == 'FRA': plt.title("France: Confidence interval - Method 3")
plt.legend()
plt.show(block=False)

# Minimum
minimum = np.zeros(length_test_period)
for i in range(length_test_period):
    minimum[i] = np.amin(H_curves[i,:])

# Percentile 10
percentile_10 = np.zeros(length_test_period)
for i in range(length_test_period):
    percentile_10[i] = np.percentile(H_curves[i,:],10)

# Median
percentile_50 = np.zeros(length_test_period)
for i in range(length_test_period):
    percentile_50[i] = np.percentile(H_curves[i,:],50)
    
# Percentile 90
percentile_90 = np.zeros(length_test_period)
for i in range(length_test_period):
    percentile_90[i] = np.percentile(H_curves[i,:],90)
    
# Maximum
maximum = np.zeros(length_test_period)
for i in range(length_test_period):
    maximum[i] = np.amax(H_curves[i,:])

plt.figure(figsize=(10,8))
plt.plot(dates[train_t_start-60:test_t_end+1], total_in[train_t_start-60:test_t_end+1], "-", color='gray', label='Initial data')
plt.plot(time_axis[train_t_start:train_t_end],H[train_t_start:train_t_end],'b--', label="H_train")
plt.plot(dates[train_t_end:test_t_end+1], percentile_90, '-g', label='p_90')
plt.plot(dates[train_t_end:test_t_end+1], percentile_50, '-k', label='Median')
plt.plot(dates[train_t_end:test_t_end+1], percentile_10, '-r', label='p_10')
plt.xlabel("Dates")
plt.ylabel("Values")
if sw_dataset == 'BEL': plt.title("Belgium: Confidence interval - Method 3")
if sw_dataset == 'FRA': plt.title("France: Confidence interval - Method 3")
plt.legend()
plt.show(block=False)

print(" ")
print("Percentile 90: ", percentile_90)
print(" ")
print("Percentile 10: ", percentile_10)

plt.figure(figsize=(10,8))
plt.plot(dates[train_t_start-60:test_t_end+1], total_in[train_t_start-60:test_t_end+1], "-", color='gray', label='Initial data')
plt.plot(time_axis[train_t_start:train_t_end],H[train_t_start:train_t_end],'b--', label="H_train")
plt.plot(dates[train_t_end:test_t_end+1], maximum, "--", color = 'c', label='Maximum')
plt.plot(dates[train_t_end:test_t_end+1], minimum, "--", color = 'm', label='Minimum')
plt.xlabel("Dates")
plt.ylabel("Values")
if sw_dataset == 'BEL': plt.title("Belgium: Confidence interval - Method 3")
if sw_dataset == 'FRA': plt.title("France: Confidence interval - Method 3")
plt.legend()
plt.show(block=False)

index_min = np.argmin(beta_bar_tab)
index_max = np.argmax(beta_bar_tab)
# print(index_min)
# print(index_max)
plt.figure(figsize=(10,8))
plt.plot(dates[train_t_start-60:test_t_end+1], total_in[train_t_start-60:test_t_end+1], "-", color='gray', label='Initial data')
plt.plot(time_axis[train_t_start:train_t_end],H[train_t_start:train_t_end],'b--', label="H_train")
plt.plot(dates[train_t_end:test_t_end+1], H_curves[:,index_max], "-", color = 'g', label='Max beta_bar')
plt.plot(dates[train_t_end:test_t_end+1], H_curves[:,index_min], "-", color = 'r', label='Min beta_bar')
plt.xlabel("Dates")
plt.ylabel("Values")
if sw_dataset == 'BEL': plt.title("Belgium: Confidence interval - Method 3")
if sw_dataset == 'FRA': plt.title("France: Confidence interval - Method 3")
plt.legend()
plt.show(block=False)


print(" ")
print("Maximum forecasts on test set: ", maximum)
print(" ")
print("Minimum forecasts on test set: ", minimum)

print(" ")
print("Beta_bar min: ", np.amin(beta_bar_tab))
# BEL: 1.0343652905816479e-05
# FRA: 6.288233181756411e-07
print(" ")
print("Beta_bar max: ", np.amax(beta_bar_tab))
# BEL: 1.0646540873440532e-05
# FRA: 6.473181216427219e-07

print(" ")
print("Beta_bar on the train period: ", beta_bar_tab)

print("Script run time:", datetime.now() - startTime)  # Show execution time

input("Press Enter to finish script execution")

